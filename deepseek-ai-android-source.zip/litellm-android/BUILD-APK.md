# Build the APK on GitHub (no Android SDK needed on your phone)

1. Create a new GitHub repository and upload the contents of this folder (the files inside `litellm-android`, not the parent folder).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`/`master`).
4. When the workflow completes, open the run and download the `LiteLLMChat-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer it to your phone and install it. Android may ask you to allow installs from that source.

This creates a debug APK, not a Play Store release APK. Do not commit API keys or proxy credentials to the repository.
