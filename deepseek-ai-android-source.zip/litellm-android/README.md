# DeepSeek AI for Android

A small Android WebView chat client for a LiteLLM gateway. It is a separate, Claude-inspired interface, not an Anthropic product.

## Features
- Loads model IDs from `GET /v1/models`.
- Sends chat requests to `POST /v1/chat/completions`.
- Lets you configure the proxy URL and optional gateway key inside the app.
- Stores the optional key in Android app-private SharedPreferences; it is not placed in the HTML or source repository.
- Uses Android's system document picker for images, videos, and documents.
- Sends images as OpenAI-compatible `image_url` content and extracts up to five representative JPEG frames from videos on-device.
- Reads small text/code files into the prompt. PDF/DOC/DOCX are currently identified but their text is not extracted; convert those to TXT or paste text for now.

## Build an APK

This source project requires Android SDK Platform 35 and JDK 17, with Android Gradle Plugin 8.6.1. Open this folder in Android Studio and allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will normally be at `app/build/outputs/apk/debug/app-debug.apk`.

This environment did not have the Android SDK or Gradle installed, so an APK has not been compiled here. The ZIP contains the complete Android Studio project source.

## Connect to your phone's LiteLLM

1. Start LiteLLM in Termux and confirm `curl http://127.0.0.1:7220/v1/models` works from Termux.
2. Install and open the APK on the same Android phone.
3. Tap the gear and keep `http://127.0.0.1:7220` as the base URL.
4. If your LiteLLM proxy requires a master key, enter that key in the app's settings. For your existing configuration, this is the value stored in `~/claude-source/litellm-master` (do not share it). Leave the field blank if the proxy does not require authentication.
5. Tap Save & connect and select a model.

The URL `127.0.0.1` means the same phone. Do not use it if LiteLLM is running on another device; use that device's LAN address instead, with appropriate network and firewall configuration.

## Limitations and security
- Image and video-frame analysis only works if the selected upstream model/provider supports vision and the gateway forwards image content.
- Videos are not uploaded as video files; up to five frames are extracted on-device and sent as images.
- Text documents are limited to 3 MB and 30,000 characters in the prompt. Images are limited to 12 MB. Videos can be large, but frame extraction is device-dependent.
- The app uses cleartext HTTP for local loopback compatibility. Do not point it at an untrusted network URL over HTTP. Use HTTPS for a remote endpoint.
- The gateway key is stored in app-private preferences, but this basic project does not encrypt it with Android Keystore. Use a dedicated low-privilege key where possible and do not share the device with untrusted users.
- The UI sends requests to `/v1/chat/completions`; if your proxy only exposes a different endpoint, adjust the Kotlin request paths accordingly.
