package com.example.litellmchat

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.*
import android.net.Uri
import android.provider.OpenableColumns
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.Base64
import org.json.JSONObject
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("proxy_settings", MODE_PRIVATE) }
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val PICK_FILE = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "application/pdf", "text/*", "application/json", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(intent, PICK_FILE)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "NativeBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE) {
            val uris = mutableListOf<Uri>()
            if (resultCode == RESULT_OK && data != null) {
                data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
                if (uris.isEmpty()) data.data?.let { uris.add(it) }
            }
            fileCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
            fileCallback = null
            if (uris.isNotEmpty()) {
                executor.execute {
                    val arr = JSONArray()
                    for (uri in uris) arr.put(readUri(uri))
                    val js = "window.NativePickedFiles && window.NativePickedFiles(" + JSONObject.quote(arr.toString()) + ");"
                    runOnUiThread { web.evaluateJavascript(js, null) }
                }
            }
        }
    }

    private fun readUri(uri: Uri): JSONObject {
        return try {
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { c.getString(it) } else null
            } ?: "attachment"
            if (mime.startsWith("video/")) {
                val retriever = MediaMetadataRetriever(); retriever.setDataSource(this, uri)
                val duration = (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
                val times = if (duration > 0) listOf(0L, duration/4, duration/2, (duration*3)/4, (duration-1).coerceAtLeast(0L)).distinct() else listOf(0L)
                val frames = JSONArray()
                for (t in times) {
                    val bmp = retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                    val width = minOf(768, bmp.width); val scaled = Bitmap.createScaledBitmap(bmp, width, (bmp.height.toFloat()*width/bmp.width).toInt().coerceAtLeast(1), true)
                    val bytes = ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG, 75, bytes)
                    frames.put(JSONObject().put("mime", "image/jpeg").put("data", Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)).put("timeMs", t/1000))
                    if (scaled !== bmp) scaled.recycle(); bmp.recycle()
                }
                retriever.release(); JSONObject().put("name", name).put("mime", mime).put("kind", "video").put("frames", frames)
            } else if (mime.startsWith("image/")) {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size > 12*1024*1024) throw Exception("Image is larger than 12 MB")
                JSONObject().put("name", name).put("mime", mime).put("kind", "image").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
            } else {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size > 3*1024*1024) throw Exception("Document is larger than 3 MB")
                JSONObject().put("name", name).put("mime", mime).put("kind", "document").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
            }
        } catch (e: Exception) { JSONObject().put("error", e.message ?: "Could not read file") }
    }

    inner class Bridge {
        @JavascriptInterface fun pickFiles() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*", "application/pdf", "text/*", "application/json", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(intent, PICK_FILE)
            }
        }
        @JavascriptInterface fun getSettings(): String = JSONObject().put("baseUrl", prefs.getString("baseUrl", "http://127.0.0.1:7220")).put("hasKey", !prefs.getString("apiKey", "").isNullOrBlank()).toString()
        @JavascriptInterface fun saveSettings(baseUrl: String, apiKey: String) {
            val safeUrl = baseUrl.trim().trimEnd('/')
            val edit = prefs.edit().putString("baseUrl", safeUrl)
            if (apiKey.isNotBlank()) edit.putString("apiKey", apiKey.trim())
            edit.apply()
        }
        @JavascriptInterface fun request(id: String, path: String, method: String, body: String) {
            executor.execute {
                var status = 0
                var result = ""
                try {
                    val base = prefs.getString("baseUrl", "http://127.0.0.1:7220")!!.trimEnd('/')
                    val key = prefs.getString("apiKey", "") ?: ""
                    val target = URL(base + "/" + path.trimStart('/'))
                    val conn = target.openConnection() as HttpURLConnection
                    conn.requestMethod = method.uppercase()
                    conn.connectTimeout = 20000
                    conn.readTimeout = 120000
                    conn.setRequestProperty("Accept", "application/json")
                    if (key.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $key")
                    if (method.uppercase() != "GET") {
                        conn.doOutput = true
                        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                    status = conn.responseCode
                    val stream = if (status >= 400) conn.errorStream else conn.inputStream
                    result = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    conn.disconnect()
                } catch (e: Exception) { result = JSONObject().put("error", e.message ?: "Network error").toString() }
                val js = "window.NativeBridgeResult && window.NativeBridgeResult(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(result) + ");"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }
        }

        @JavascriptInterface fun readFile(uriString: String, callbackId: String) {
            executor.execute {
                var output = JSONObject()
                try {
                    val uri = Uri.parse(uriString)
                    val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                    val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { c.getString(it) } else null
                    } ?: "attachment"
                    if (mime.startsWith("video/")) {
                        val retriever = MediaMetadataRetriever()
                        retriever.setDataSource(this@MainActivity, uri)
                        val duration = (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
                        val frames = JSONArray()
                        val times = if (duration > 0) listOf(0L, duration/4, duration/2, (duration*3)/4, (duration-1).coerceAtLeast(0L)).distinct() else listOf(0L)
                        for (t in times) {
                            val bmp = retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                            val scaled = Bitmap.createScaledBitmap(bmp, minOf(768, bmp.width), (bmp.height.toFloat() * minOf(768, bmp.width) / bmp.width).toInt().coerceAtLeast(1), true)
                            val bytes = ByteArrayOutputStream(); scaled.compress(Bitmap.CompressFormat.JPEG, 75, bytes)
                            frames.put(JSONObject().put("mime", "image/jpeg").put("data", Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)).put("timeMs", t/1000))
                            if (scaled !== bmp) scaled.recycle(); bmp.recycle()
                        }
                        retriever.release()
                        output = JSONObject().put("name", name).put("mime", mime).put("kind", "video").put("frames", frames)
                    } else if (mime.startsWith("image/")) {
                        val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                        if (bytes.size > 12 * 1024 * 1024) throw Exception("Image is larger than 12 MB")
                        output = JSONObject().put("name", name).put("mime", mime).put("kind", "image").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    } else {
                        val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                        if (bytes.size > 3 * 1024 * 1024) throw Exception("Document is larger than 3 MB; choose a smaller file")
                        output = JSONObject().put("name", name).put("mime", mime).put("kind", "document").put("data", Base64.encodeToString(bytes, Base64.NO_WRAP))
                    }
                } catch (e: Exception) { output = JSONObject().put("error", e.message ?: "Could not read file") }
                val js = "window.NativeFileResult && window.NativeFileResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(output.toString()) + ");"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }
        }
    }

    override fun onDestroy() { web.removeJavascriptInterface("NativeBridge"); executor.shutdownNow(); super.onDestroy() }
}
